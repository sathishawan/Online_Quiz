import React, { Component } from 'react';  
import Select from 'react-select';  
import makeAnimated from 'react-select/animated';  
import axios from 'axios';  
  
const animatedComponents = makeAnimated();  
export class Multiselect extends Component {  
        constructor(props) {  
                super(props)  
  
                this.state = {  
                        country: [],  
                          
                }  
        }  
        componentWillMount() {  
                fetch('http://localhost:8080/api/auth/signin').then(response => {  
                        console.log(response);  
                        this.setState({  
                                country: response.data  
  
                        })  
  
                })  
  
        }  
        Country() {  
                return (this.state.country.map(data => ({ label: data.name, value: data.name })))  
        }  
          
        render() {  
                return (  
                        <>  
                                <div class="row" className="hdr">  
                                  
                                </div>  
                                 <div className="container">  
                                 <div className="row">  
                                 <div className="col-md-3"></div>  
                                <div className="col-xs-6">  
                                 <Select  options={this.Country()} components={animatedComponents}  
                                                                        isMulti />  
                                 </div>  
                                 <div className="col-md-4"></div>  
                                 </div>  
                                </div>  
                           
                        </>  
                )  
        }  
}  
export default Multiselect  