import React, { Component } from 'react'
import Multiselect from './Multiselect'  

class Auth extends Component {
    constructor(props) {
        super(props);

        this.state = {
            optionsdata : [ ],
            isRegister: false
        }
    }

    // handleChange = (e) => {
    //     console.log(e.target.value);
    //     var value = this.state.optionsdata.filter(function(item) {
    //       return item.key == e.target.value
    //     })
    //     console.log(value[0].value);
    //   }


    login() {
        console.warn("state", this.state);
        fetch('http://localhost:8080/api/auth/signin', {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",

            },
            body: JSON.stringify(this.state)
        }).then((result) => {
            result.json().then((resp) => {
                console.log(resp.accessToken);
                localStorage.setItem("auth", JSON.stringify(resp.accessToken))
            })
        })
    }

    register() {
        console.warn("state", this.state);
        fetch('http://localhost:8080/api/auth/signup', {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",

            },
            body: JSON.stringify(this.state)
        }).then((result) => {
            result.json().then((resp) => {
                console.log(resp.accessToken);
                localStorage.setItem("auth", JSON.stringify(resp.accessToken))
            })
        })
    }

    render() {

        const {optionsdata} =this.state;  

        return (
            <div>
                {
                    !this.state.isRegister ?
                        <div>
                            <input type="text"
                                placeholder="user name"
                                onChange={(e) => { this.setState({ username: e.target.value }) }} />
                            <br /><br />
                            <input type="text"
                                placeholder="password"
                                onChange={(e) => { this.setState({ password: e.target.value }) }} />
                            <br /><br />
                            <button onClick={() => this.login()} >Login</button>  &nbsp;
                            <button onClick={() => this.setState({ isRegister: true })} >Go to Register</button>

                        </div>
                        :
                        <div>

                            <input type="text"
                                placeholder="user name"
                                onChange={(e) => { this.setState({ username: e.target.value }) }} />
                            <br /><br />
                            <input type="text"
                                placeholder="email"
                                onChange={(e) => { this.setState({ email: e.target.value }) }} />
                            <br /><br />
                            <input type="text"
                                placeholder="password"
                                onChange={(e) => { this.setState({ password: e.target.value }) }} />
                            <br /><br />
                            <select onChange={this.handleChange}>
                            <option value="none" selected disabled hidden> 
                            Select Role 
                            </option> 
                            {optionsdata.map(function(data, key){  return (
                            <option key={key} value={data.key}>{data.value}</option> )
                            })}
                        </select>
                            <br /><br />
                            <button onClick={() => this.register()} >Register</button> &nbsp;
                            <button onClick={() => this.setState({ isRegister: false })} >Go to Login</button>

                        </div>
                }

            </div>
        )
    }
}

export default Auth;
