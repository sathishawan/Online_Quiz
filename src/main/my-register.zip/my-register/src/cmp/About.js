import React, { Component } from 'react'

class About extends Component {
    render(){
    return (
        <div>
            About Component
        </div>
    )
    }
}

export default About;
