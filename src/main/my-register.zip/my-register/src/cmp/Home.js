import React, { Component } from 'react'

class Home extends Component {
    render(){
    return (
        <div>
            Home Component
        </div>
    )
    }
}

export default Home;
