import React, { Component } from 'react'

class Listing extends Component {
    render(){
    return (
        <div>
            Listing Component
        </div>
    )
    }
}

export default Listing;
