import React, { Component } from 'react'
import { Redirect } from 'react-router-dom';
import Login from './Login'

class Register extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
            Roles: [],
            selectedRole: [],
            isRegister:false
             
        }
    }

    componentDidMount(){
        fetch('http://localhost:8080/api/auth/get_roles')
        .then(response => response.json())
        .then(Roles => this.setState({Roles:Roles}))
    }

    register() {
        console.warn("state", this.state);
        fetch('http://localhost:8080/api/auth/signup', {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",

            },
            body: JSON.stringify(this.state)
        }).then((result) => {
            result.json().then((resp) => {
                // console.log(resp.accessToken);
                localStorage.setItem("auth", JSON.stringify(resp.accessToken));
                this.setState({isRegister:true})
            })
        })
    }
    

    render(){

        if(this.state.isRegister)
        {
            return (<Redirect to={Login}/>)
        }

    return (
                        <div>

                            <input type="text"
                                placeholder="user name"
                                onChange={(e) => { this.setState({ username: e.target.value }) }} />
                            <br /><br />
                            <input type="text"
                                placeholder="email"
                                onChange={(e) => { this.setState({ email: e.target.value }) }} />
                            <br /><br />
                            <input type="password"
                                placeholder="password"
                                onChange={(e) => { this.setState({ password: e.target.value }) }} />
                            <br /><br />
                      
                                <select
                                    value={this.state.selectedRole}
                                    onChange={e => this.setState({selectedRole: e.target.value})}>
                                    <option value="">--choose Role--</option>
                                    {this.state.Roles.map((role) =>
                                     <option value={role.value}>{role.name}</option>)}
                                </select>
                            
                            <br /><br /><br/><br/>
                           
                            <button class="btn-primary" onClick={() => this.register()} >Register</button>
                            <br/><br/>
                             <p>Already register?? <a href="/login"><b>Login</b></a></p>
                       
                        </div>

    )
}
}

export default Register
