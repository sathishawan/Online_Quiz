import React, { Component } from 'react';
import {PostData} from '../services/PostData';
import {Redirect} from 'react-router-dom'
import './style.css';




class Admin extends Component {
    constructor(props) {
        super(props);

       this.state ={
          
          username:'',
          password:'',
          redirect:false,
          fields: {},
          errors: {}
  
  
       };
       this.login = this.login.bind(this);
       this.onChange = this.onChange.bind(this);
    }


     
    login() {
        // const isValid = this.validate();
    PostData(this.state).then((result)=>{
    let responseJSON = result;
    console.log(responseJSON);
    if(responseJSON.accessToken){
          console.log(responseJSON.accessToken);
         localStorage.setItem("userData", JSON.stringify(responseJSON.accessToken));
         this.setState({redirect:true});
    }
    
    if (this.validateForm()) {
      let fields = {};
      fields["username"] = "";
      
      fields["password"] = "";
      this.setState({fields:fields});
      alert("Form submitted");
  }
    })

    }
    validateForm() {

      let fields = this.state.fields;
      let errors = {};
      let formIsValid = true;

      if (!fields["username"]) {
        formIsValid = false;
        errors["username"] = "*Please enter your username.";
      }
      if (typeof fields["username"] !== "undefined") {
        
          formIsValid = false;
          errors["username"] = "*invalid username.";
        }
      
      if (!fields["password"]) {
        formIsValid = false;
        errors["password"] = "*Please enter your password.";
      }
      if (typeof fields["password"] !== "undefined")  {
        
        formIsValid = false;
        errors["password"] = "*invalid password.";
      }
   

     

      this.setState({
        errors: errors
      });
      return formIsValid;


    }




onChange(e){
this.setState({[e.target.name] : e.target.value});
console.log(this.state);
let fields = this.state.fields;
      fields[e.target.name] = e.target.value;
      this.setState({
        fields
      });

    }


    render() {

        if(this.state.redirect){

        return (<Redirect to ={'/Home'} />);

        }

        if(localStorage.getItem("userData")){

        return (<Redirect to ={'/home'} />);

        }

      
        return (
          
          <div id="register">
                    <h3>Admin Login page</h3>
                    <br/>

                              <label>User Name</label>

                        <input placeholder="username" type="text" name="username" value={this.state.fields.username} onChange={this.onChange} />
                                  <div  style={{ fontSize: 12, color: "red", }}className="errorMsg">{this.state.errors.username}</div>
                                  <br/>
                                  <label>Password</label>

                            <input placeholder="password" type="password" name="password" value={this.state.fields.password} onChange={this.onChange} />
                                <div  style={{ fontSize: 12, color: "red" }}className="errorMsg">{this.state.errors.password}</div>
                                <br/>
                           
                            <button  class="btn" onClick={() => this.login()} >Login </button>
                            <br/><br/>
                            {/* <p>I'm new??  <a href="/register"> <b>Register</b></a></p> */}

          </div>

        )
    }
}

export default Admin;
