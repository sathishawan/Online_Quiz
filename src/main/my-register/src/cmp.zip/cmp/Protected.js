import React from 'react'
import { Redirect } from 'react-router-dom'

function Protected(props) {
    const cmp = props.cmp
    var auth = JSON.parse(localStorage.getItem('userData'))
    console.warn(auth)

    return <div>{auth ? <cmp /> : <Redirect to="login"></Redirect>}</div>

}

export default Protected;
