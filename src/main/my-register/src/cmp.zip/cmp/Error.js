import React, { Component } from 'react';
import img from './img.png'; 



export default class Error extends Component {
    render() {
        return (
            <div>
     <img src={img} alt="Page Not Found!!" />

</div>
        )
    }
}
